#!/bin/bash
echo "Date"
echo "Enter Month and date: $1";
echo "Enter Time HH:MM:SS AM/PM Format: $2';
cat $1_Dealer_schedule | awk -F”\t” ‘{print $1, $2}’ | grep -w “$2”
